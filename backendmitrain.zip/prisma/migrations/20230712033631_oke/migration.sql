-- AlterTable
ALTER TABLE `post` MODIFY `description` VARCHAR(1000) NULL;
